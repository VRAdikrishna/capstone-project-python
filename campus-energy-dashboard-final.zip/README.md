# Campus Energy Dashboard – FINAL VERSION (Option B)
Includes:
- Fully working Python project
- Sample datasets
- Auto-created output folder
- Dashboard image INCLUDED
- launch.json for VS Code
- Clean modular structure

Run using:
python -m src.main
